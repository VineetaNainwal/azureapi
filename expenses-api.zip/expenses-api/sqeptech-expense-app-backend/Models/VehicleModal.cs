﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    class VehicleModal
    {
        public int vehicleId { get; set; }
        public string vehicleName { get; set; }
    }
    public class CreateVehicleModal
    {
        public string vehicleName { get; set; }
    }
    public class UpdateVehicleModal
    {
        public string vehicleName { get; set; }
    }
}
