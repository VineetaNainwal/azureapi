﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
     public class VATModal
    {
        public int VATId { get; set; }

        public string VATName { get; set; }
    }
    public class CreateVATModel
    {
        public string VATName { get; set; }
    }
    public class UpdateVATModel
    {
        public string VATName { get; set; }
    }
}
