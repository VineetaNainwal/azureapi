﻿
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Recurring")]
    public class RecurringOptions
    {

        //create recurs

        [FunctionName("RecurringOptions")]
        public static async Task<IActionResult> CreateRecurs(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "recurs")]
          [RequestBodyType(typeof(CreateRecursModel), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateRecursModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.recursName))
                {
                    var query = $"INSERT INTO [Recurs] (recursName) VALUES('{input.recursName}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Recurring Options created successfully", status = HttpStatusCode.OK });
        }

        //all recurs

        [FunctionName("GetRecurs")]
        public static async Task<IActionResult> GetRecurs(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "recurs")] HttpRequest req, ILogger log)
        {
            List<RecurringOptionsModal> RecursList = new List<RecurringOptionsModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select recursId, recursName from Recurs";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    RecurringOptionsModal task = new RecurringOptionsModal()
                    {
                        recursId = (int)reader["recursId"],
                        recursName = reader["recursName"].ToString()

                    };
                    RecursList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (RecursList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = RecursList,
                    count = RecursList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by recurs Id

        [FunctionName("GetRecursById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "recurs/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select recursId, recursName from Recurs Where recursId = @recursId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@recursId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete recurs

        [FunctionName("DeleteRecurs")]
        public static IActionResult DeleteRecurs(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "recurs/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Recurs Where recursId = @recursId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@recursId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Recurring Options deleted successfully", status = HttpStatusCode.OK });
        }

        //update recurs

        [FunctionName("UpdateRecurs")]
        public static async Task<IActionResult> UpdateRecurs(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "recurs/{id}")]
        [RequestBodyType(typeof(UpdateRecursModel), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateRecursModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Recurs Set recursName = @recursName Where recursId = @recursId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@recursName", input.recursName);
                command.Parameters.AddWithValue("@recursId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Recurring Options updated successfully", status = HttpStatusCode.OK });
        }
        

    }

}

