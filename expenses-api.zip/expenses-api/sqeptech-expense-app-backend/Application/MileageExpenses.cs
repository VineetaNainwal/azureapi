﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "MileageExpenses")]
    public class MileageExpenses
    {
        //create Mileage Expenses
        [FunctionName("MileageExpenses")]
        public static async Task<IActionResult> CreateMileageExpense(
                    [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "mileageExpense")]
          [RequestBodyType(typeof(CreateMileageExpensesModal), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateMileageExpensesModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();

                var query = $"INSERT INTO [MileageExpenses] (mileage,mileageExpenseDate,vehicleId,description,projectId,reciept,recursId) VALUES('{input.mileage}','{input.mileageExpenseDate}','{input.vehicleId}','{input.description}','{input.projectId}','{input.reciept}','{input.recursId}')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Mileage Expense created successfully", status = HttpStatusCode.OK });
        }

        //all Mileage Expenses

        [FunctionName("GetMileageExpenses")]
        public static async Task<IActionResult> GetMileageExpenses(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "mileageExpenses")] HttpRequest req, ILogger log)
        {
            List<MileageExpensesModal> MileageExpenseList = new List<MileageExpensesModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select *  from MileageExpenses";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    MileageExpensesModal task = new MileageExpensesModal()
                    {
                        mileageExpenseId = (int)reader["mileageExpenseId"],
                        mileage = (int)reader["mileage"],
                        mileageExpenseDate = (DateTime)reader["mileageExpenseDate"],
                        vehicleId = (int)reader["vehicleId"],
                        description = reader["description"].ToString(),
                        projectId = (int)reader["projectId"],
                        reciept = reader["reciept"].ToString(),
                        recursId = (int)reader["recursId"],

                    };
                    MileageExpenseList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (MileageExpenseList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = MileageExpenseList,
                    count = MileageExpenseList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by Mileage expense Id

        [FunctionName("GetMileageExpenseById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "mileageExpense/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select* from MileageExpenses Where mileageExpenseId = @mileageExpenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@mileageExpenseId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Mileage Expense

        [FunctionName("DeleteMileageExpense")]
        public static IActionResult DeleteExpense(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "mileageExpense/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from MileageExpense Where mileageExpenseId = @mileageExpenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@mileageExpenseId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Mileage Expense Deleted successfully", status = HttpStatusCode.OK });
        }

        //update Mileage expense

        [FunctionName("UpdateMileageExpense")]
        public static async Task<IActionResult> UpdateExpense(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "mileageExpense/{id}")]
        [RequestBodyType(typeof(UpdateMileageExpensesModal), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateMileageExpensesModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update MileageExpenses Set mileage = @mileage , mileageExpenseDate = @mileageExpenseDate,vehicleId = @vehicleId,description = @description,projectId = @projectId,reciept = @reciept,recursId = @recursId Where mileageExpenseId = @mileageExpenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@mileage", input.mileage);
                command.Parameters.AddWithValue("@mileageExpenseDate", input.mileageExpenseDate);
                command.Parameters.AddWithValue("@vehicleId", input.vehicleId);
                command.Parameters.AddWithValue("@description", input.description);
                command.Parameters.AddWithValue("@projectId", input.projectId);
                command.Parameters.AddWithValue("@reciept", input.reciept);
                command.Parameters.AddWithValue("@recursId", input.recursId);
                command.Parameters.AddWithValue("@mileageExpenseId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Mileage Expense Updated successfully", status = HttpStatusCode.OK });
        }
    }

}
