﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Categories")]
    public class Categories
    {

        //create Category

        [FunctionName("Categories")]
      
        public static async Task<IActionResult> CreateCategory(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "category")]
          [RequestBodyType(typeof(CreateCategoryModel), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateCategoryModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.name))
                {
                    var query = $"INSERT INTO [Categories] (name) VALUES('{input.name}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
                else
                {
                    return new BadRequestObjectResult( new { message = "404 Bad request" , statuscode = HttpStatusCode.BadRequest });
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                throw new Exception(e.ToString());
            }
            return new OkObjectResult(new { message = "Category created successfully", status = HttpStatusCode.OK });
        }

        //all Categories

        [FunctionName("GetCategories")]
      
        public static async Task<IActionResult> GetCategories(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "categories")] HttpRequest req, ILogger log)
        {
            List<AllCategories> CategoriesList = new List<AllCategories>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select categoryId, name from Categories";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    AllCategories task = new AllCategories()
                    {
                        categoryId = (int)reader["categoryId"],
                        name = reader["name"].ToString()

                    };
                    CategoriesList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (CategoriesList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = CategoriesList,
                    count = CategoriesList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by Category Id

        [FunctionName("GetCategoryById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "category/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select categoryId, name from Categories Where categoryId = @categoryId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@categoryId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Category

        [FunctionName("DeleteCategory")]
        public static IActionResult DeleteCategory(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "category/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Categories Where categoryId = @categoryId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@categoryId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Category Deleted successfully", status = HttpStatusCode.OK });
        }

        //update Category

        [FunctionName("UpdateCategory")]
        public static async Task<IActionResult> UpdateCategory(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "category/{id}")]
        [RequestBodyType(typeof(UpdateCategoryModel), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateCategoryModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Categories Set name = @name Where categoryId = @categoryId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", input.name);
                command.Parameters.AddWithValue("@categoryId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Category Updated successfully", status = HttpStatusCode.OK });
        }
    }

}
