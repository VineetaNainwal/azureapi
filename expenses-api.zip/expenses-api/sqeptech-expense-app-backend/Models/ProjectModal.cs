﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    public class ProjectModal
    {
        public int projectId { get; set; }

        public string projectName { get; set; }
    }
    public class CreateProjectModal
    {
        public string projectName { get; set; }
    }
    public class UpdateProjectModal
    {
        public string projectName { get; set; }
    }
}
