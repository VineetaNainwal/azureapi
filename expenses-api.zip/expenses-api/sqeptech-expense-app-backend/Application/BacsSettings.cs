﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "BacsSettings")]
    public class BacsSettings
    {

        [FunctionName("BacsSettings")]
        public static async Task<IActionResult> CreateBacs(
                   [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "bacs")]
          [RequestBodyType(typeof(CreateSettingModel), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateSettingModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();

                var query = $"INSERT INTO [bacsSettings] (bankName,bankBranch,bankReference,accountName,accountNumber,sortCode,bankPaymentFormat,bacsSun,paymentReferenceFormat,settings,includeAttachment,includeDeductions,rejectEmployee) VALUES('{input.bankName}','{input.bankBranch}','{input.bankReference}','{input.accountName}','{input.accountNumber}','{input.sortCode}','{input.bankPaymentFormat}','{input.bacsSun}', '{input.paymentReferenceFormat}','{input.settings}','{input.includeAttachment}','{input.includeDeductions}','{input.rejectEmployee}')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Bank settings saved successfully", status = HttpStatusCode.OK });
        }

        //all Expenses

        [FunctionName("GetBacsSettings")]
        public static async Task<IActionResult> GetExpenses(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "bacs")] HttpRequest req, ILogger log)
        {
            List<BacsSettingsModal> bacsSettingsList = new List<BacsSettingsModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select *  from bacsSettings";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    BacsSettingsModal task = new BacsSettingsModal()
                    {
                        bankId = (int)reader["bankId"],
                        bankName = reader["bankName"].ToString(),
                        bankBranch = reader["bankBranch"].ToString(),
                        bankReference = reader["bankReference"].ToString(),
                        accountName = reader["accountName"].ToString(),
                        accountNumber = reader["accountNumber"].ToString(),
                        sortCode = reader["sortCode"].ToString(),
                        bankPaymentFormat = reader["bankPaymentFormat"].ToString(),
                        bacsSun = reader["bacsSun"].ToString(),
                        paymentReferenceFormat = reader["paymentReferenceFormat"].ToString(),
                        settings = reader["settings"].ToString(),
                        includeAttachment = (bool)reader["includeAttachment"],
                        includeDeductions = (bool)reader["includeAttachment"],
                        rejectEmployee = (bool)reader["includeAttachment"],
                    };
                    bacsSettingsList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (bacsSettingsList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = bacsSettingsList,
                    count = bacsSettingsList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by expense Id

        [FunctionName("GetBacsSettingById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "bacs/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select* from bacsSettings Where bankId = @bankId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@bankId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Expense

        [FunctionName("DeleteBacsSetting")]
        public static IActionResult DeleteBacsSetting(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "bacs/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from bacsSettings Where bankId = @bankId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@bankId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Bank Settings Deleted successfully", status = HttpStatusCode.OK });
        }

        //update expense

        [FunctionName("UpdateBacsSetting")]
        public static async Task<IActionResult> UpdateExpense(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "bacs/{id}")]
        [RequestBodyType(typeof(UpdateSettingModel), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateSettingModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Expenses Set bankName = @bankName , bankBranch = @bankBranch,bankReference = @bankReference,accountName = @accountName,accountNumber = @accountNumber,sortCode = @sortCode,bankPaymentFormat = @bankPaymentFormat,bacsSun = @bacsSun,paymentReferenceFormat = @paymentReferenceFormat ,settings = @settings,includeAttachment = @includeAttachment,includeDeductions = @includeDeductions,rejectEmployee = @rejectEmployee Where bankId = @bankId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@bankName", input.bankName);
                command.Parameters.AddWithValue("@bankBranch", input.bankBranch);
                command.Parameters.AddWithValue("@bankReference", input.bankReference);
                command.Parameters.AddWithValue("@accountName", input.accountName);
                command.Parameters.AddWithValue("@accountNumber", input.accountNumber);
                command.Parameters.AddWithValue("@sortCode", input.sortCode);
                command.Parameters.AddWithValue("@bankPaymentFormat", input.bankPaymentFormat);
                command.Parameters.AddWithValue("@bacsSun", input.bacsSun);
                command.Parameters.AddWithValue("@paymentReferenceFormat", input.paymentReferenceFormat);
                command.Parameters.AddWithValue("@settings", input.settings);
                command.Parameters.AddWithValue("@includeAttachment", input.includeAttachment);
                command.Parameters.AddWithValue("@includeDeductions", input.includeDeductions);
                command.Parameters.AddWithValue("@rejectEmployee", input.rejectEmployee);
                command.Parameters.AddWithValue("@bankId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Bank settings Updated successfully", status = HttpStatusCode.OK });
        }
    }

}