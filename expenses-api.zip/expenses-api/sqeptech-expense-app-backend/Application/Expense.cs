﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;
namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Expenses")]
    public class Expense
    {
        //create Expenses

        [FunctionName("Expenses")]
        public static async Task<IActionResult> CreateExpense(
              [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "expense")]
          [RequestBodyType(typeof(CreateExpenseModal), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateExpenseModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();

                var query = $"INSERT INTO [Expenses] (categoryId,expenseDate,currencyId,totalValue,VATId,description,projectId,reciept,recursId) VALUES('{input.categoryId}','{input.expenseDate}','{input.currencyId}','{input.totalValue}','{input.VATId}','{input.description}','{input.projectId}','{input.reciept}', '{input.recursId}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Expense created successfully", status = HttpStatusCode.OK });
        }

        //all Expenses

        [FunctionName("GetExpenses")]
        public static async Task<IActionResult> GetExpenses(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "expense")] HttpRequest req, ILogger log)
        {
            List<ExpenseModal> ExpenseList = new List<ExpenseModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select *  from Expenses";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    ExpenseModal task = new ExpenseModal()
                    {
                        expenseId = (int)reader["expenseId"],
                        categoryId = (int)reader["categoryId"],
                        expenseDate = (DateTime)reader["expenseDate"],
                        currencyId = (int)reader["currencyId"],
                        totalValue = (int)reader["totalValue"],
                        VATId = (int)reader["VATId"],
                        description = reader["description"].ToString(),
                        projectId = (int)reader["projectId"],
                        reciept = reader["Reciept"].ToString(),
                        recursId = (int)reader["recursId"],
                        
                    };
                    ExpenseList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (ExpenseList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = ExpenseList,
                    count = ExpenseList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by expense Id

        [FunctionName("GetExpenseById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "expense/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select* from Expenses Where expenseId = @expenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@expenseId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Expense

        [FunctionName("DeleteExpense")]
        public static IActionResult DeleteExpense(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "expense/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Expenses Where expenseId = @expenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@expenseId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Expense Deleted successfully", status = HttpStatusCode.OK });
        }

        //update expense

        [FunctionName("UpdateExpense")]
        public static async Task<IActionResult> UpdateExpense(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "expense/{id}")]
        [RequestBodyType(typeof(UpdateExpenseModal), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateExpenseModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Expenses Set categoryId = @categoryId , expenseDate = @expenseDate,currencyId = @currencyId,totalValue = @totalValue,VATId = @VATId,description = @description,projectId = @projectId,reciept = @reciept,recursId = @recursId Where expenseId = @expenseId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@categoryId", input.categoryId);
                command.Parameters.AddWithValue("@expenseDate", input.expenseDate);
                command.Parameters.AddWithValue("@currencyId", input.currencyId);
                command.Parameters.AddWithValue("@totalValue", input.totalValue);
                command.Parameters.AddWithValue("@VATId", input.VATId);
                command.Parameters.AddWithValue("@description", input.description);
                command.Parameters.AddWithValue("@projectId", input.projectId);
                command.Parameters.AddWithValue("@reciept", input.reciept);
                command.Parameters.AddWithValue("@recursId", input.recursId);
                command.Parameters.AddWithValue("@expenseId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Expense Updated successfully", status = HttpStatusCode.OK });
        }
    }

}
