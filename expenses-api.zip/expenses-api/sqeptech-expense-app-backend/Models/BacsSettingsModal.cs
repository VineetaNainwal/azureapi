﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    public class BacsSettingsModal
    {
        public int bankId { get; set; }
        public string bankName { get; set; }
        public string bankBranch { get; set; }
        public string bankReference { get; set; }
        public string settings { get; set; }
        public string accountName { get; set; }
        public string accountNumber { get; set; }
        public string sortCode { get; set; }
        public string bankPaymentFormat { get; set; }
        public string bacsSun { get; set; }
        public string paymentReferenceFormat { get; set; }
        public bool includeAttachment { get; set; }
        public bool includeDeductions { get; set; }
        public bool rejectEmployee { get; set; }

    }
    public class CreateSettingModel
    {
        public string bankName { get; set; }
        public string bankBranch { get; set; }
        public string bankReference { get; set; }
        public string accountName { get; set; }
        public string accountNumber { get; set; }
        public string sortCode { get; set; }
        public string bankPaymentFormat { get; set; }
        public string bacsSun { get; set; }
        public string paymentReferenceFormat { get; set; }
        public string settings { get; set; }
        public bool includeAttachment { get; set; }
        public bool includeDeductions { get; set; }
        public bool rejectEmployee { get; set; }
    }
    public class UpdateSettingModel
    {
        public string bankName { get; set; }
        public string bankBranch { get; set; }
        public string bankReference { get; set; }
        public string accountName { get; set; }
        public string accountNumber { get; set; }
        public string sortCode { get; set; }
        public string bankPaymentFormat { get; set; }
        public string bacsSun { get; set; }
        public string paymentReferenceFormat { get; set; }
        public string settings { get; set; }
        public bool includeAttachment { get; set; }
        public bool includeDeductions { get; set; }
        public bool rejectEmployee { get; set; }
    }
}
