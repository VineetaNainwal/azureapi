﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Project")]
    public class Project
    {
        //create Project

        [FunctionName("Project")]
        public static async Task<IActionResult> CreateProject(
         [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "project")]
          [RequestBodyType(typeof(CreateProjectModal), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateProjectModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.projectName))
                {
                    var query = $"INSERT INTO [Project] (projectName) VALUES('{input.projectName}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Project created successfully", status = HttpStatusCode.OK });
        }

        //all projects

        [FunctionName("GetProject")]
        public static async Task<IActionResult> GetProject(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "project")] HttpRequest req, ILogger log)
        {
            List<ProjectModal> ProjectList = new List<ProjectModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select projectId, projectName from Project";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    ProjectModal task = new ProjectModal()
                    {
                        projectId = (int)reader["projectId"],
                        projectName = reader["projectName"].ToString()

                    };
                    ProjectList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (ProjectList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = ProjectList,
                    count = ProjectList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by project Id

        [FunctionName("GetProjectById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "project/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select projectId, projectName from Project Where projectId = @projectId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@projectId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete project

        [FunctionName("DeleteProject")]
        public static IActionResult DeleteProject(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "project/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Project Where projectId = @projectId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@projectId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Project deleted successfully", status = HttpStatusCode.OK });
        }

        //update project

        [FunctionName("UpdateProject")]
        public static async Task<IActionResult> UpdateCategory(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "project/{id}")]
        [RequestBodyType(typeof(UpdateProjectModal), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateProjectModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Project Set projectName = @projectName Where projectId = @projectId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@projectName", input.projectName);
                command.Parameters.AddWithValue("@projectId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Project updated successfully", status = HttpStatusCode.OK });
        }
    }
}
