﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "VAT")]
    public class VAT
    {
        //create  Vat

        [FunctionName("VAT")]
        public static async Task<IActionResult> CreateVAT(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "VAT")]
          [RequestBodyType(typeof(CreateVATModel), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateVATModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.VATName))
                {
                    var query = $"INSERT INTO [VAT] (name) VALUES('{input.VATName}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Category created successfully", status = HttpStatusCode.OK });
        }
    
        //All  Vat

        [FunctionName("GetVAT")]
        public static async Task<IActionResult> GetVAT(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "VAT")] HttpRequest req, ILogger log)
        {
            List<VATModal> VATList = new List<VATModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select VATId, VATName from VAT";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    VATModal task = new VATModal()
                    {
                        VATId = (int)reader["VATId"],
                        VATName = reader["VATName"].ToString()

                    };
                    VATList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (VATList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = VATList,
                    count = VATList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }


        }

        //get Vat by Id

        [FunctionName("GetVATById")]
        public static IActionResult GetTaskById(
      [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "VAT/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select VATId, VATName from VAT Where VATId = @VATId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@VATId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Vat

        [FunctionName("DeleteVAT")]
        public static IActionResult DeleteVAT(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "VAT/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from VAT Where VATId = @VATId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@VATId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "VAT  deleted successfully", status = HttpStatusCode.OK });
        }

        //update Vat

        [FunctionName("UpdateVAT")]
        public static async Task<IActionResult> UpdateVAT(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "VAT/{id}")]
        [RequestBodyType(typeof(UpdateVATModel), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateVATModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update VAT Set VATName = @VATName Where VATId = @VATId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@VATName", input.VATName);
                command.Parameters.AddWithValue("@VATId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "VAT  updated successfully", status = HttpStatusCode.OK });
        }

    }
}
