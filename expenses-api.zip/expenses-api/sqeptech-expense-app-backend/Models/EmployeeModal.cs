﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    public class EmployeeModal
    {
        public int empId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string status { get; set; }
        public string address { get; set; }
    }
    public class CreateEmloyeeModel
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string status { get; set; }
        public string address { get; set; }
    }
    public class UpdateEmloyeeModel
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string status { get; set; }
        public string address { get; set; }
    }
}
