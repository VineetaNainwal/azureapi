﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Vehicles")]
    public class Vehicle
    {
        //create vehicle

        [FunctionName("Vehicles")]
        public static async Task<IActionResult> CreateVehicle(
              [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "vehicles")]
          [RequestBodyType(typeof(CreateVehicleModal), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateVehicleModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.vehicleName))
                {
                    var query = $"INSERT INTO [Vehicles] (vehicleName) VALUES('{input.vehicleName}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
                else
                {
                    return new BadRequestObjectResult(new { message = "404 Bad request", statuscode = HttpStatusCode.BadRequest });
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                throw new Exception(e.ToString());
            }
            return new OkObjectResult(new { message = "Vehicle created successfully", status = HttpStatusCode.OK });
        }

        //all vehicles

        [FunctionName("GetVehicles")]
        public static async Task<IActionResult> GetVehicles(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "vehicles")] HttpRequest req, ILogger log)
        {
            List<VehicleModal> VehicleList = new List<VehicleModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select vehicleId, vehicleName from Vehicles";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    VehicleModal task = new VehicleModal()
                    {
                        vehicleId = (int)reader["vehicleId"],
                        vehicleName = reader["vehicleName"].ToString()

                    };
                    VehicleList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (VehicleList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = VehicleList,
                    count = VehicleList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by vehicle Id

        [FunctionName("GetVehicleById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "vehicle/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select vehicleId, vehicleName from Categories Where vehicleId = @vehicleId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@vehicleId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete vehicle

        [FunctionName("DeleteVehicle")]
        public static IActionResult DeleteVehicle(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "vehicle/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Categories Where vehicleId = @vehicleId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@vehicleId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Vehicle Deleted successfully", status = HttpStatusCode.OK });
        }

        //update vehicle

        [FunctionName("UpdateVehicle")]
        public static async Task<IActionResult> UpdateVehicle(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "vehicle/{id}")]
        [RequestBodyType(typeof(UpdateVehicleModal), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateVehicleModal>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Categories Set vehicleName = @vehicleName Where vehicleId = @vehicleId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@vehicleName", input.vehicleName);
                command.Parameters.AddWithValue("@vehicleId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Vehicle Updated successfully", status = HttpStatusCode.OK });
        }
    }

}
