﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    public class MileageExpensesModal
    {
        public int mileageExpenseId { get; set; }
        public int mileage { get; set; }
        public DateTime mileageExpenseDate { get; set; }
        public int vehicleId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
    public class CreateMileageExpensesModal
    {
        public int mileage { get; set; }
        public DateTime mileageExpenseDate { get; set; }
        public int vehicleId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
    public class UpdateMileageExpensesModal
    {
        public int mileage { get; set; }
        public DateTime mileageExpenseDate { get; set; }
        public int vehicleId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
}