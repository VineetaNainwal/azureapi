﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
   public class CurrencyModal
    {
        public int currencyId { get; set; }

        public string currencyName { get; set; }
    }
    public class CreateCurrencyModel
    {
        public string currencyName { get; set; }
    }
    public class UpdateCurrencyModel
    {
        public string currencyName { get; set; }
    }
}

