﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
    public class ExpenseModal
    {
        public int expenseId { get; set; }
        public int categoryId { get; set; }
        public DateTime expenseDate { get; set; }
        public int currencyId { get; set; }
        public int totalValue { get; set; }
        public int VATId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
    public class CreateExpenseModal
    {
        public int categoryId { get; set; }
        public DateTime expenseDate { get; set; }
        public int currencyId { get; set; }
        public int totalValue { get; set; }
        public int VATId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
    public class UpdateExpenseModal
    {
        public int categoryId { get; set; }
        public DateTime expenseDate { get; set; }
        public int currencyId { get; set; }
        public int totalValue { get; set; }
        public int VATId { get; set; }
        public string description { get; set; }
        public int projectId { get; set; }
        public string reciept { get; set; }
        public int recursId { get; set; }
    }
}
