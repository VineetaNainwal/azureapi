﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;


namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Employees")]
    public  class Employee
    { 
  [FunctionName("Employee")]
    public static async Task<IActionResult> CreateEmployee(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "employee")]
          [RequestBodyType(typeof(CreateEmloyeeModel), "request")] HttpRequest req, ILogger log)
    {
        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        var input = JsonConvert.DeserializeObject<CreateEmloyeeModel>(requestBody);
        try
        {
            using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
            connection.Open();
            if (!String.IsNullOrEmpty(input.firstName))
            {
                var query = $"INSERT INTO [Employee] (firstName,lastName,status,address) VALUES('{input.firstName}','{input.lastName}','{input.status}','{input.address}')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
            }
            else
            {
                return new BadRequestObjectResult(new { message = "404 Bad request", statuscode = HttpStatusCode.BadRequest });
            }
        }
        catch (Exception e)
        {
            log.LogError(e.ToString());
            throw new Exception(e.ToString());
        }
        return new OkObjectResult(new { message = "Employee created successfully", status = HttpStatusCode.OK });
    }

    //all Employees

    [FunctionName("GetEmployees")]
    public static async Task<IActionResult> GetEmployees(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "employees")] HttpRequest req, ILogger log)
    {
        List<EmployeeModal> EmployeeList = new List<EmployeeModal>();
        try
        {
            using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
            connection.Open();
            var query = @"Select * from Employee";
            SqlCommand command = new SqlCommand(query, connection);
            var reader = await command.ExecuteReaderAsync();
            while (reader.Read())
            {
                    EmployeeModal task = new EmployeeModal()
                {
                    empId = (int)reader["empId"],
                    firstName = reader["firstName"].ToString(),
                    lastName = reader["lastName"].ToString(),
                    status = reader["status"].ToString(),
                    address = reader["address"].ToString(),
                    };
                    EmployeeList.Add(task);
            }
        }
        catch (Exception e)
        {
            log.LogError(e.ToString());
        }
        if (EmployeeList.Count > 0)
        {
            return new OkObjectResult(new
            {
                data = EmployeeList,
                count = EmployeeList.Count,
                itemsPerPage = 10

            });
        }
        else
        {
            return new NotFoundResult();
        }
    }

    //get by Employee Id

    [FunctionName("GetEmployeeById")]
    public static IActionResult GetTaskById(
   [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "employee/{id}")] HttpRequest req, ILogger log, int id)
    {
        DataTable dt = new DataTable();
        try
        {
            using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
            connection.Open();
            var query = @"Select * from Employee Where empId = @empId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@empId", id);
            SqlDataAdapter da = new SqlDataAdapter(command);
            da.Fill(dt);
        }
        catch (Exception e)
        {
            log.LogError(e.ToString());
        }
        if (dt.Rows.Count == 0)
        {
            return new NotFoundResult();
        }
        return new OkObjectResult(dt);
    }


    //delete Employee

    [FunctionName("DeleteEmployee")]
    public static IActionResult DeleteEmployee(
    [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "employee/{id}")] HttpRequest req, ILogger log, int id)
    {
        try
        {
            using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
            connection.Open();
            var query = @"Delete from Employee Where empId = @empId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@empId", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            log.LogError(e.ToString());
            return new BadRequestResult();
        }
        return new OkObjectResult(new { message = "Employee Deleted successfully", status = HttpStatusCode.OK });
    }

    //update Employee

    [FunctionName("UpdateEmployee")]
    public static async Task<IActionResult> UpdateEmployee(
    [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "employee/{id}")]
        [RequestBodyType(typeof(UpdateEmloyeeModel), "request")] HttpRequest req, ILogger log, int id)
    {
        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        var input = JsonConvert.DeserializeObject<UpdateEmloyeeModel>(requestBody);
        try
        {
            using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
            connection.Open();
                var query = @"Update Employee Set firstName = @firstName , lastName = @lastName,address = @address,status = @status Where empId = @empId";
                SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@firstName", input.firstName);
            command.Parameters.AddWithValue("@lastName", input.lastName);
            command.Parameters.AddWithValue("@address", input.address);
            command.Parameters.AddWithValue("@status", input.status);
            command.Parameters.AddWithValue("@empId", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            log.LogError(e.ToString());
        }
        return new OkObjectResult(new { message = "Employee Updated successfully", status = HttpStatusCode.OK });
    }
}

}
