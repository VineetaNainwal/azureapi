﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
   public  class AllCategories
    {
        public int categoryId { get; set; }
        public string name { get; set; }
    }
    public class CreateCategoryModel
    {
        public string name { get; set; }
    }
    public class UpdateCategoryModel
    {
        public string name { get; set; }
    }
}
