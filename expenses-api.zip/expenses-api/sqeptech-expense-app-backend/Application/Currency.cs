﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Collections.Generic;
using sqeptech_expense_app_backend.Models;
using AzureFunctions.Extensions.Swashbuckle.Attribute;
using System.Data;
using System.Net;

namespace sqeptech_expense_app_backend.Application
{
    [ApiExplorerSettings(GroupName = "Currency")]
    public class Currency
    {
       
        //create Currency

        [FunctionName("Currency")]
        public static async Task<IActionResult> CreateCurrency(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "currency")]
          [RequestBodyType(typeof(CreateCurrencyModel), "request")] HttpRequest req, ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<CreateCurrencyModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                if (!String.IsNullOrEmpty(input.currencyName))
                {
                    var query = $"INSERT INTO [Currency] (currencyName) VALUES('{input.currencyName}')";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Currency created successfully", status = HttpStatusCode.OK });
        }

        //all Currency

        [FunctionName("GetCurrency")]
        public static async Task<IActionResult> GetCurrency(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "currency")] HttpRequest req, ILogger log)
        {
            List<CurrencyModal> CurrencyList = new List<CurrencyModal>();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select currencyId, currencyName from Currency";
                SqlCommand command = new SqlCommand(query, connection);
                var reader = await command.ExecuteReaderAsync();
                while (reader.Read())
                {
                    CurrencyModal task = new CurrencyModal()
                    {
                        currencyId = (int)reader["currencyId"],
                        currencyName = reader["currencyName"].ToString()

                    };
                    CurrencyList.Add(task);
                }
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (CurrencyList.Count > 0)
            {
                return new OkObjectResult(new
                {
                    data = CurrencyList,
                    count = CurrencyList.Count,
                    itemsPerPage = 10

                });
            }
            else
            {
                return new NotFoundResult();
            }
        }

        //get by Currency Id

        [FunctionName("GetCurrencyById")]
        public static IActionResult GetTaskById(
       [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "currency/{id}")] HttpRequest req, ILogger log, int id)
        {
            DataTable dt = new DataTable();
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Select currencyId, currencyName from Currency Where currencyId = @currencyId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@currencyId", id);
                SqlDataAdapter da = new SqlDataAdapter(command);
                da.Fill(dt);
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            if (dt.Rows.Count == 0)
            {
                return new NotFoundResult();
            }
            return new OkObjectResult(dt);
        }


        //delete Currency

        [FunctionName("DeleteCurrency")]
        public static IActionResult DeleteCurrency(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "currency/{id}")] HttpRequest req, ILogger log, int id)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Delete from Currency Where currencyId = @currencyId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@currencyId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
                return new BadRequestResult();
            }
            return new OkObjectResult(new { message = "Currency Deleted successfully", status = HttpStatusCode.OK });
        }

        //update Currency

        [FunctionName("UpdateCurrency")]
        public static async Task<IActionResult> UpdateCategory(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "currency/{id}")]
        [RequestBodyType(typeof(UpdateCurrencyModel), "request")] HttpRequest req, ILogger log, int id)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateCurrencyModel>(requestBody);
            try
            {
                using SqlConnection connection = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnectionString"));
                connection.Open();
                var query = @"Update Currency Set currencyName = @currencyName Where currencyId = @currencyId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@currencyName", input.currencyName);
                command.Parameters.AddWithValue("@currencyId", id);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                log.LogError(e.ToString());
            }
            return new OkObjectResult(new { message = "Currency updated successfully", status = HttpStatusCode.OK });
        }
    }

}
