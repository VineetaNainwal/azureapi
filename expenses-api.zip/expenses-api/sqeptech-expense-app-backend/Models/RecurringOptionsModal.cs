﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqeptech_expense_app_backend.Models
{
   public  class RecurringOptionsModal
    {
        public int recursId { get; set; }

        public string recursName { get; set; }
    }
    public class CreateRecursModel
    {
        public string recursName { get; set; }
    }
    public class UpdateRecursModel
    {
        public string recursName { get; set; }
    }
}
